#include <time.h>
#include "mysort.h"

void generateNums(int *myarr, int len)
{
	int i;
	srand(time(NULL));//make sure the generated random numbers will depend on time so we can see some variety

	for(i = 0; i < len; i++){
		myarr[i] = rand() % 101;//the random numbers will be in the range 0~100
	}
}

//selection sort: you should have learned this sorting algorithm in PPI
void sortNums(int *myarr, int len)
{
	int i,j;
	for (i = 0; i < len - 1; i++) {
      int currentMin = myarr[i];
      int currentMinIndex = i;

      for (j = i + 1; j < len; j++) {
        if (currentMin > myarr[j]) {
          currentMin = myarr[j];
          currentMinIndex = j;
        }
      }

      // Swap myarr[i] with myarr[currentMinIndex] if necessary;
      if (currentMinIndex != i) {
        myarr[currentMinIndex] = myarr[i];
        myarr[i] = currentMin;
      }
    }
}

//insertion sort: another sorting algorithm you might learn in future in Algorithms course
// void sortNums(int *myarr, int len)
// {
	// int i,j,t;
	// for(i = 1; i < len; i++){
		// t = myarr[i];
		// j=i-1;
		// while(j >= 0 && myarr[j] >t)
		// {
			// myarr[j+1] = myarr[j];
			// j--;
		// }
		// myarr[j+1]=t;
	// }
// }
