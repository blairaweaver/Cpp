#include <stdio.h>
#include <stdlib.h>

void generateNums(int *myarr, int len);
void sortNums(int *myarr, int len);
