//to compile: gcc A2p4.c -o A2p4
//to run: ./A2p4
//Notice that char's are stored as integers using ASCII table rule
//and you can print their integer values with %d in printf.
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	char c;
	//printf("printing upper case English characters:\n");
	for(c='A';c<='Z';c++)
	{
		printf("%c\tASCII value:%d\n",c,c);//notice the difference between %c and %d
	}
	//printf("printing lower case English characters:\n");
	for(c='a';c<='z';c++)
	{
		printf("%c\tASCII value:%d\n",c,c);
	}
	//printf("printing ten decimal digit characters:\n");
	for(c='0';c<='9';c++)
	{
		printf("%c\tASCII value:%d\n",c,c);
	}
	return 0;
}