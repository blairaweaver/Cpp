//to compile: gcc A2p2.c -o A2p2
//to run: ./A2p2
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	int i;
	for(i=0;i<5;i++)
	{
		printf("hello world\n");
	}
	printf("\n");
	while(i<10)
	{
		printf("hello world\n");
		i++;
	}
	printf("\n");
	do
	{
		printf("hello world\n");
		i++;
	}while(i<15);
	return 0;
}